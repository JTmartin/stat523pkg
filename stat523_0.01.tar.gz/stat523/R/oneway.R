#' The following are a group of functions that perform onewway anova
#'
#' This function takes a named list and performs oneway anova
#' @param z a list if only one varaiable is passed else a factor
#' @param y a numeric vector containing responses
#' @param formula a symbolic description of the model
#' @param data a data.frame containing the response in col 1 and factors in col 2
#' @return an object which includes the rawdata, SSbtwn, SSwithin, DFbtwn,
#'  DFwithin and the call. In the case of summary it returns a summary object
#' @keywords oneway
#' @export
#'
oneway <- function(z, ...) UseMethod("oneway")

#' @describeIn oneway oneway.default(z, ...)
#' @export
oneway.default <- function(z, ...) {
  rawdata_num <- sapply(z,length)
  rawdata_sum <- sapply(z,sum)
  SS_btwn <- sum(rawdata_sum^2 / rawdata_num) - sum(rawdata_sum)^2 /sum(rawdata_num)
  sumrawdatasq<-sum(sapply(sapply(z,function(x)x^2),sum))

  SS_total <- sumrawdatasq - sum(rawdata_sum)^2 / sum(rawdata_num)
  SS_within <- SS_total - SS_btwn

  df_btwn <- length(rawdata_num) - 1
  df_within <- sum(rawdata_num) - length(rawdata_num)

  AOV<-list(SSbtwn=SS_btwn,SSwithin=SS_within,
            DFbtwn=df_btwn,DFwithin=df_within)
  AOV$rawdata<-z
  AOV$call<-match.call()
  class(AOV)<-"oneway"
  AOV
}

#' @describeIn oneway oneway.factor(z, y, ...)
#' @export
oneway.factor <- function(z, y, ...) {
  #expects an input of a factor z (representing the groups), and a numeric vector y
  AOV<-oneway(split(as.numeric(y),factor(z)))
  AOV$call<-match.call()
  AOV
}

#' @describeIn oneway oneway.formula(formula, data, ...)
#' @export
oneway.formula <- function(formula, data=data.frame(), ...) {
  #model formula for the standard R models
  mf_AOV<-model.frame(formula=formula, data=data)
  z<-mf_AOV$z
  y<-mf_AOV$y
  AOV<-oneway.factor(z,y,...)
  AOV$call<-match.call()
  AOV$formula<-formula
  AOV
}

#' @describeIn oneway print.oneway(x, ...)
#' @param x an object of class oneway
#' @param \dots unused
#' @export
print.oneway <- function(x, ...) {
  cat("Call:\n")
  print(x$call)

  cat("\nBasic stats of our data:\n")
  printCoefmat(with(AOV,cbind(mean=sapply(rawdata,mean),
                              var=sapply(rawdata,var))))
  cat("\n\nSome AOV details:")
  cat("\nSum of squares between: ",paste(x$SSbtwn))
  cat(" with ",paste(x$DFbtwn)," degrees of freedom.")
  cat("\nSum of squares within: ",paste(x$SSwithin))
  cat(" with ",paste(x$DFwithin)," degrees of freedom.")
}

#' @describeIn oneway summary.oneway(x, ...)
#' @param x an object of class oneway
#' @export
summary.oneway <- function(object, ...) {
  #summary method that generates a summary object, does not print to screen
  SAOV<-object
  SAOV$mean_btwn<-SAOV$SSbtwn/SAOV$DFbtwn
  SAOV$mean_within<-SAOV$SSwithin/SAOV$DFwithin
  SAOV$Fvalue<-SAOV$mean_btwn/SAOV$mean_within

  SAOV$Pvalue<-pf(SAOV$Fvalue,SAOV$DFbtwn,SAOV$DFwithin,lower.tail=FALSE)

  tab<-with(SAOV, cbind(DF = c(DFbtwn,DFwithin),
                        SS= c(SSbtwn,SSwithin),
                        MS= c(mean_btwn, mean_within),
                        Fv= c(Fvalue,NA),
                        "Prob (>F)"=c(Pvalue,NA)))
  rownames(tab) <- c("Trt", "Residuals")
  SAOV$tab<-tab
  class(SAOV)<-"summary.oneway"
  SAOV
}

#' @describeIn oneway print.summary.oneway(x, ...)
#' @param x an object of class summary.oneway
#' @export
print.summary.oneway <- function(x, ...) {
  # print method for the summary object.
  cat("Analysis of Variance Table:\n")
  printCoefmat(x$tab, P.values=T, has.Pvalue=T,
               signof.stars=T, na.print="")
  #   cat("Source\tDf\tSumSq\tMeanSq \t F val.\t Prob.\n",
  #     "Btwn\t",x$DFbtwn,"\t",x$SSbtwn,"\t",x$mean_btwn,
  #     "\t",signif(x$Fvalue,digit=4),"\t",signif(x$Pvalue,digits=4),
  #     "\n","wthn\t",x$DFwithin,"\t",x$SSwithin,"\t",x$mean_within)
}

#' @describeIn oneway plot.oneway(x, ...)
#' @param x an object of class oneway
#' @export
plot.oneway <- function(x, ...) {
  # Plot generic function compares distribution of the groups.
  boxplot(x$rawdata)
}
