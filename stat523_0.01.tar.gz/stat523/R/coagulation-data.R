#' @name coagulation
#' @title Coagulation data from the Faraway library
#' @description This data is a data.frame containing 2 variables. $coag
#'  contains coagulation responses as numeric and $diet contains the 4
#'  diets as a factor
#' @format A data framw with:
#' \describe{
#'  \item{coag}{coagulation responses}
#'  \item{diet}{4 different diets}}
#' @docType data
#'
#' @usage coagulation
NULL
